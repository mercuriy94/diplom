PC-Lint Update Files
--------------------
The following files are the updated LINT command files and
error translator for PC-Lint for C51.

LINTXLAT.EXE
KEILC51.LNT

To install this update, copy these files into the \C51\BIN
directory.  Then, use the KEILC51.LNT file with PC-LINT.

