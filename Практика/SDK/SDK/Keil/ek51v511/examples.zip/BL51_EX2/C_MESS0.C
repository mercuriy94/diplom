/*------------------------------------------------------------------------------
C_MESS0.C

Copyright 1995 KEIL Software, Inc.
------------------------------------------------------------------------------*/

code char *message0[] = {
  "This is a message from code-bank 0\n",
  "This is another text message from bank 0\n"
};
