/*------------------------------------------------------------------------------
C_MESS1.C

Copyright 1995 KEIL Software, Inc.
------------------------------------------------------------------------------*/

code char *message1[] = {
  "This is a message from code-bank 1\n",
  "This is another text message from bank 1\n"
};

