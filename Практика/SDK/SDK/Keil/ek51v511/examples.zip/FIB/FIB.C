/*------------------------------------------------------------------------------
FIB.C:  A small recursive program that calculates Fibonacci numbers.
  
This program was originally featured in the "Embedded Systems Magazine"
April 1989
------------------------------------------------------------------------------*/

#include <stdio.h>
#include <reg51.h>

unsigned fib (int n) reentrant
  {
    if (n <= 2) return 1;
    return fib(n-1) + fib(n-2);
  }

unsigned results[11];

main()
  {
    int loop;

  SCON = 0x52;    /* SCON */
  TMOD = 0x20;    /* TMOD */
  TCON = 0x69;    /* TCON */
  TH1 =  0xf3;    /* TH1 */

    for (loop=1; loop < 10; loop++)
      {
        results[loop] = fib(loop);
      }

    for (loop=1; loop < 10; loop++)
      {
        printf("fib(%d) = %d\n",loop,results[loop]);
      }
    while (1);
  }

