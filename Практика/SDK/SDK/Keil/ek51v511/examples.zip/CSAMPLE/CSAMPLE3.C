/*------------------------------------------------------------------------------
CSAMPLE3.C

Copyright 1995 KEIL Software, Inc.
------------------------------------------------------------------------------*/

#include <stdio.h>                             /* define I/O functions */

char dummy_buffer [25];                        /* only for demostration */
 
output (int number)  {
  printf ("\nresult: %d\n\n", number);
}
