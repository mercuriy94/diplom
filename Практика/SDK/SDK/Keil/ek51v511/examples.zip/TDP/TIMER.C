/*------------------------------------------------------------------------------
TIMER.C:  Timer tick routines.

Copyright 1995 KEIL Software, Inc.
------------------------------------------------------------------------------*/

#include "tdp.h"
#include <reg51.h>

/*------------------------------------------------------------------------------
		 Local Macro and Manifest Constant Declarations
------------------------------------------------------------------------------*/
#define TIMER0_COUNT		0xDC11		/* 10000h - ((11,059,200 Hz / (12 * FREQ)) - 17)  */

/*------------------------------------------------------------------------------
			  Local Variable Declarations
------------------------------------------------------------------------------*/
static xdata unsigned timer0_tick;

/*------------------------------------------------------------------------------
static void timer0_isr (void);

This function is an interrupt service routine for TIMER 0.  It should never
be called by a C or assembly function.  It will be executed automatically
when TIMER 0 overflows.
------------------------------------------------------------------------------*/
static void timer0_isr (void) interrupt 1 using 1
{
P1 |= 0x80;

/*------------------------------------------------
Adjust the timer 0 counter so that we get another
interrupt in 10ms.
------------------------------------------------*/
TR0 = 0;				/* stop timer 0 */

TL0 = TL0 + (TIMER0_COUNT & 0x00FF);
TH0 = TH0 + (TIMER0_COUNT >> 8);

TR0 = 1;				/* start timer 0 */

/*------------------------------------------------
Increment the timer tick.  This interrupt should
occur approximately every 1ms. So, the resulotion
of the timer will be 1kHz not including interrupt
latency.
------------------------------------------------*/
timer0_tick++;

P1 &= ~0x80;
}

/*------------------------------------------------------------------------------
void timer0_initialize (void);

This function enables TIMER 0.  TIMER 0 will generate a synchronous interrupt
once every 1kHz.
------------------------------------------------------------------------------*/
void timer0_initialize (void)
{
INT_DISABLE;			/* disable interrupts */

timer0_tick = 0;

TR0 = 0;			/* stop timer 0 */

TMOD &= ~0x0F;			/* clear timer 0 mode bits */
TMOD |= 0x01;			/* put timer 0 into 16-bit no prescale */

TL0 = (TIMER0_COUNT & 0x00FF);
TH0 = (TIMER0_COUNT >> 8);

PT0 = 0;			/* set low priority for timer 0 */
ET0 = 1;			/* enable timer 0 interrupt */

TR0 = 1;			/* start timer 0 */

INT_ENABLE;			/* enable interrupts */
}

/*------------------------------------------------------------------------------
unsigned timer0_count (void);

This function returns the current timer0 tick count.
------------------------------------------------------------------------------*/
unsigned timer0_count (void)
{
xdata unsigned t;

INT_DISABLE;
t = timer0_tick;
INT_ENABLE;

return (t);
}

/*------------------------------------------------------------------------------
unsigned timer0_elapsed_count (
  unsigned count);

This function returns the number of timer ticks that have elapsed since the
specified count.
------------------------------------------------------------------------------*/
unsigned timer0_elapsed_count (
  unsigned count)
{
return (timer0_count () - count);
}

/*------------------------------------------------------------------------------
void timer0_wait (
  unsigned count);

This function waits for 'count' timer ticks to pass.
------------------------------------------------------------------------------*/
void timer0_wait (
  unsigned count)
{
xdata unsigned start_count;

start_count = timer0_count ();

while (timer0_elapsed_count (start_count) <= count)
  {
  }
}

/*------------------------------------------------------------------------------
------------------------------------------------------------------------------*/



