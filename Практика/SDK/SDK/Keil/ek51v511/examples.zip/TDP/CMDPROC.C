/*------------------------------------------------------------------------------
CMDPROC.C:  Routines to interpret command lines.

Copyright 1995 KEIL Software, Inc.
------------------------------------------------------------------------------*/

#include <ctype.h>
#include <string.h>
#include "tdp.h"

/*------------------------------------------------------------------------------
------------------------------------------------------------------------------*/
static pdata char helptext [] =
  "\r\n\r\n"
  "HELP:\r\n"
  "STCLK hhmmss -- Set Clock Time\r\n"
  "RDCLK        -- Display Clock Time\r\n"
  "SCCLK ON|OFF -- Display Clock Time Every Second\r\n"
  "STALM hhmm   -- Set Alarm\r\n"
  "RDALM        -- Display Alarm Time\r\n"
  "CLALM        -- Clear Alarm Time\r\n"
  "\r\n";

/*------------------------------------------------------------------------------
Commands:
HELP
STCLK HHMMSS
RDCLK
SCCLK
STALM HHMM
RDALM
CLALM

Responses:
TIME: HH:MM:SS.HH	(current time)
ALARM: HH:MM		(alarm time)
<beep>			(alarm - for one minute only)
------------------------------------------------------------------------------*/
enum
  {
  CID_SET_CLK,
  CID_READ_CLK,
  CID_SCAN_CLK,

  CID_SET_ALM,
  CID_READ_ALM,
  CID_CLR_ALM,

  CID_LAST
  };

struct cmd_st
  {
  const char *cmdstr;
  unsigned char id;
  };

static pdata struct cmd_st cmd_tbl [] =
  {
    { "STCLK",		CID_SET_CLK },
    { "RDCLK",		CID_READ_CLK },
    { "SCCLK",		CID_SCAN_CLK },
    { "STALM",		CID_SET_ALM },
    { "RDALM",		CID_READ_ALM },
    { "CLALM",		CID_CLR_ALM },
  };

#define CMD_TBL_LEN (sizeof (cmd_tbl) / sizeof (cmd_tbl [0]))

/*------------------------------------------------------------------------------
------------------------------------------------------------------------------*/
static unsigned char cmdid_search (
  char *cmdstr)
{
struct cmd_st *ctp;

for (ctp = cmd_tbl; ctp < &cmd_tbl [CMD_TBL_LEN]; ctp++)
  {
  if (strcmp (ctp->cmdstr, cmdstr) == 0)
    return (ctp->id);
  }

return (CID_LAST);
}

/*------------------------------------------------------------------------------
------------------------------------------------------------------------------*/
char *strupr (
  char *src)
{
for (; *src != '\0'; src++)
  *src = toupper (*src);
}

/*------------------------------------------------------------------------------
------------------------------------------------------------------------------*/
void cmd_proc (
  const char *cmd)
{
xdata char cmdstr_buf [1 + MAX_CMD_LEN];
xdata char argstr_buf [1 + MAX_CMD_LEN];
char *argsep;
unsigned char id;

/*------------------------------------------------
------------------------------------------------*/
strncpy (cmdstr_buf, cmd, sizeof (cmdstr_buf) - 1);
cmdstr_buf [sizeof (cmdstr_buf) - 1] = '\0';
strupr (cmdstr_buf);

argsep = strchr (cmdstr_buf, ' ');

/*------------------------------------------------
------------------------------------------------*/
if (argsep == NULL)
  {
  argstr_buf [0] = '\0';
  }
else
  {
  strcpy (argstr_buf, argsep + 1);
  *argsep = '\0';
  }

/*------------------------------------------------
------------------------------------------------*/
id = cmdid_search (cmdstr_buf);

switch (id)
  {
  unsigned long tm;

  case CID_SET_CLK:
    if (strtotm (&tm, argstr_buf) != 0)
      goto CMDERR;
    clock_set (tm * 100);
    break;

  case CID_READ_CLK:
    clock_out_time ();
    break;
    
  case CID_SCAN_CLK:
    if (strcmp (argstr_buf, "ON") == 0)
      clock_scan (1);
    else if (strcmp (argstr_buf, "OFF") == 0)
      clock_scan (0);
    else
      goto CMDERR;
    break;

  case CID_SET_ALM:
    strcat (argstr_buf, "00");
    if (strtotm (&tm, argstr_buf) != 0)
      goto CMDERR;
    alarm_set (tm / 60);
    break;

  case CID_READ_ALM:
    alarm_out_time ();
    break;

  case CID_CLR_ALM:
    alarm_clr ();
    break;

  case CID_LAST:
CMDERR:
    com_puts (helptext);
    break;
  }

/*------------------------------------------------
------------------------------------------------*/
}

/*------------------------------------------------------------------------------
------------------------------------------------------------------------------*/

