#ifndef _KB_H
#define _KB_H

extern bit ScanKBOnce(char *ch);

#endif //_KB_H
