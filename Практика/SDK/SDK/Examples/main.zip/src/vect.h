#ifndef _VECT_H
#define _VECT_H

extern void SetVect(unsigned char num, void code * handler);
extern void code * GetVect(unsigned char num);

#endif //_VECT_H
