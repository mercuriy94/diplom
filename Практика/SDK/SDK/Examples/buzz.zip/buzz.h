#ifndef _BUZZ_H
#define _BUZZ_H

extern void Buzz(void);

#endif //_BUZZ_H
